# QM-MM Inhibition Pipeline

A GPU-accelerated DFT + QM/MM pipeline for computing the **molecular mechanism of inhibition** of protein–ligand complexes using real quantum chemical calculations.

---

## What This Pipeline Actually Does

| Step | Calculation | Method |
|------|-------------|--------|
| 1 | PDB parsing + binding pocket extraction | Biopython + NumPy (distance-based, 8 Å) |
| 2 | Ligand 3D mol from PDB coordinates | RDKit bond inference |
| 3 | Real DFT ground state | B3LYP/def2-SVP (PySCF + GPU4PySCF) |
| 4 | Real Fukui indices f⁺/f⁻/f⁰/Δf | N, N+1, N−1 DFT states (Mulliken condensed) |
| 5 | Real MEP from DFT electron density | Nuclear + electronic Coulomb integral |
| 6 | Real QM/MM electrostatic embedding | PySCF qmmm.mm_charge + AMBER ff14SB |
| 7 | Protein–ligand H-bond detection | Geometric criterion (≤3.5 Å) |
| 8 | Inhibition mechanism interpretation | Rule-based from DFT descriptors |
| 9 | Publication-quality figures | Matplotlib 600 DPI white background |

---

## System Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| OS | Ubuntu 20.04+ | Ubuntu 22.04+ |
| Python | 3.9+ | 3.10 |
| RAM | 16 GB | 64 GB+ |
| GPU | NVIDIA CUDA 11+ | NVIDIA CUDA 12+ |
| GPU VRAM | 6 GB | 8 GB+ |
| CPU cores | 8 | 24+ |

---

## Installation

### Step 1 — Clone the repository

```bash
git clone https://github.com/[username]/QM-MM-Inhibition-Pipeline.git
cd QM-MM-Inhibition-Pipeline
```

### Step 2 — Create a clean Python environment (recommended)

```bash
conda create -n qmmm_env python=3.10 -y
conda activate qmmm_env
```

Or with virtualenv:
```bash
python3 -m venv qmmm_env
source qmmm_env/bin/activate
```

### Step 3 — Install dependencies

```bash
pip install -r requirements.txt
```

Or manually:
```bash
pip install pyscf rdkit biopython numpy scipy matplotlib pandas morfeus-ml
```

### Step 4 — Install GPU4PySCF (for NVIDIA GPU acceleration)

For CUDA 12.x (recommended):
```bash
pip install gpu4pyscf-cuda12x
```

For CUDA 11.x:
```bash
pip install gpu4pyscf-cuda11x
```

Verify GPU is detected:
```bash
python3 -c "from gpu4pyscf import dft; print('GPU4PySCF ready')"
```

### Step 5 — Verify installation

```bash
python3 -c "
import pyscf; print('PySCF:', pyscf.__version__)
from rdkit import Chem; print('RDKit: OK')
from Bio import PDB; print('Biopython: OK')
import numpy as np; print('NumPy:', np.__version__)
print('All dependencies installed!')
"
```

---

## Usage

### Single complex

**Step 1** — Edit these 3 lines at the bottom of `real_dft_qmmm_pipeline.py`:

```python
PDB_FILE       = "your_protein_ligand.pdb"   # PDB with protein + ligand together
LIGAND_RESNAME = "AUTO"                       # AUTO = auto-detect ligand
                                              # Or set manually: "LIG", "UNK", "ATP"
FUNCTIONAL     = "B3LYP"                      # DFT functional
N_THREADS      = 24                           # CPU threads
MEP_GRID       = 30                           # MEP grid points (30=fast, 50=fine)
```

**Step 2** — Run on GPU:
```bash
CUDA_VISIBLE_DEVICES=0 python3 real_dft_qmmm_pipeline.py 2>&1 | tee run.log
```

**Step 3** — Run in background (for long jobs):
```bash
CUDA_VISIBLE_DEVICES=0 nohup python3 -u real_dft_qmmm_pipeline.py > run.log 2>&1 &
echo "PID: $!"
tail -f run.log
```

### Batch run (multiple complexes)

**Step 1** — Edit `batch_run.sh`:
```bash
PDBS=(
    "complex1.pdb"
    "complex2.pdb"
    "complex3.pdb"
    "complex4.pdb"
)
LIGAND="AUTO"    # or your ligand resname
CUDA_DEV=0       # GPU device number
```

**Step 2** — Run batch:
```bash
nohup bash batch_run.sh > batch.log 2>&1 &
tail -f batch.log
```

### Monitor progress

```bash
# Watch log file
tail -f run.log

# Monitor GPU usage
watch -n 5 nvidia-smi

# Check CPU usage
htop
```

---

## Input PDB Format

Your PDB file must contain **both protein and ligand** in the same file:

```
ATOM      1  N   ALA A   1    ...    protein atoms
...
HETATM  100  C1  LIG B   1    ...    ligand atoms (HETATM)
END
```

- Protein residues: standard `ATOM` records
- Ligand: `HETATM` records with a unique 3-letter residue name
- Ligand resname is auto-detected (largest non-protein, non-solvent residue)

---

## Output

Each run produces a results folder:

```
complex1_results/
├── fig1_ligand_quantum.png    # Charge map, MEP, Fukui indices, H-bonds (600 DPI)
├── fig2_binding_qmmm.png      # Per-residue energy, Elec vs vdW, DFT radar, HOMO/LUMO (600 DPI)
├── report.txt                 # Human-readable full report
└── report.json                # Machine-readable structured data
```

### Key results in report:

```
DFT ORBITAL ENERGIES
  SCF Energy (Ha)          : -1557.240155
  HOMO (eV)                : -1.6541
  LUMO (eV)                : -1.4333
  HOMO-LUMO gap (eV)       :  0.2208
  IP = -E(HOMO) (eV)       :  1.6541
  EA = -E(LUMO) (eV)       :  1.4333
  Electrophilicity omega   : 10.7945

MECHANISM OF INHIBITION
  Binding Mode             : Covalent / Irreversible
  Reactivity               : Soft electrophile - Covalent warhead
  Dominant Interaction     : H-bond (3) + Hydrophobic
  Electrophilicity         : Strong (omega=10.79) - Michael acceptor
```

---

## Estimated Runtime

| Ligand Size | Step 3 DFT | Step 4 Fukui | Step 6 QM/MM | Total |
|-------------|-----------|-------------|-------------|-------|
| <30 heavy atoms | ~5 min | ~15 min | ~30 min | ~1 hr |
| 30–60 atoms | ~10 min | ~30 min | ~45 min | ~1.5 hr |
| >60 atoms | ~20 min | ~60 min | ~90 min | ~3 hr |

*Tested on NVIDIA RTX 3070 Ti (8 GB), 128 GB RAM, 24 CPU threads*

---

## Troubleshooting

### ImportError: MDAnalysis
This pipeline uses **Biopython** (not MDAnalysis) to avoid numpy conflicts.
If you see MDAnalysis errors, ensure you downloaded the latest version.

### numpy dtype size changed
```bash
pip install --force-reinstall "numpy>=1.24,<2.0"
```

### GPU not detected
```bash
nvidia-smi                          # Check GPU is visible
pip install gpu4pyscf-cuda12x       # Install GPU4PySCF
python3 -c "from gpu4pyscf import dft; print('OK')"
```

### SCF not converging
Try a smaller basis set — edit in script:
```python
basis = "sto-3g"    # fastest, least accurate
basis = "def2-svp"  # default, balanced
```

### Amber libstdc++ conflict
```bash
LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6 python3 real_dft_qmmm_pipeline.py
```

---

## Citation

If you use this pipeline, please cite:

```
Dwivedi VD (2026). DFT-QMMM-Protein-Ligand-Inhibition-Pipeline: 
A GPU-accelerated DFT/QM-MM pipeline for molecular mechanism of 
inhibition analysis of protein-ligand complexes. GitHub.
https://github.com/[username]/DFT-QMMM-Protein-Ligand-Inhibition-Pipeline
```

### Also cite underlying software:

1. Sun Q, et al. PySCF: The Python‐based simulations of chemistry framework. *WIREs Comput Mol Sci.* 2018;8:e1340.
2. Wu X, et al. GPU4PySCF for periodic Hartree-Fock and DFT calculations. *arXiv:2407.09600*, 2024.
3. Becke AD. Density-functional thermochemistry. III. *J Chem Phys.* 1993;98:5648.
4. Lee C, Yang W, Parr RG. Development of the Colle-Salvetti correlation-energy formula. *Phys Rev B.* 1988;37:785.
5. Weigend F, Ahlrichs R. Balanced basis sets of split valence. *Phys Chem Chem Phys.* 2005;7:3297.
6. Yang W, Mortier WJ. The use of global and local molecular parameters. *J Am Chem Soc.* 1986;108:5708.
7. Warshel A, Levitt M. Theoretical studies of enzymic reactions. *J Mol Biol.* 1976;103:227.
8. Lipinski CA, et al. Experimental and computational approaches. *Adv Drug Deliv Rev.* 2001;46:3.
9. Bickerton GR, et al. Quantifying the chemical beauty of drugs. *Nat Chem.* 2012;4:90.
10. RDKit: Open-source cheminformatics. http://www.rdkit.org

---

## License

MIT License — see [LICENSE](LICENSE) file.

## Contact

**Dr. Vivek Dhar Dwivedi**

1. Raja Shankar Shah University, Chhindwara, Madhya Pradesh, India
2. Bioinformatics Research Division, Quanta Calculus, Greater Noida, India

📧 vivek_bioinformatics@yahoo.com
